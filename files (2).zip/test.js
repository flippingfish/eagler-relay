'use strict';
// Self-test: starts the relay + a local TCP echo server and exercises the Wisp protocol.
const net = require('net'), { spawn } = require('child_process');
const T = { CONNECT: 1, DATA: 2, CONTINUE: 3, CLOSE: 4 };
const pkt = (t, id, p) => { const b = Buffer.alloc(5 + p.length); b[0] = t; b.writeUInt32LE(id, 1); p.copy(b, 5); return b; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };

function startRelay(port, env) {
  const p = spawn(process.execPath, [__dirname + '/wisp-relay.js'], { env: { ...process.env, PORT: port, HOST: '127.0.0.1', ...env }, stdio: ['ignore', 'pipe', 'inherit'] });
  return new Promise(res => p.stdout.on('data', d => { if (/listening/.test(d)) res(p); }));
}
function open(port) {
  return new Promise((res, rej) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port + '/wisp/'); ws.binaryType = 'arraybuffer';
    const msgs = []; let wake = null;
    ws.onmessage = e => { msgs.push(Buffer.from(e.data)); if (wake) wake(); };
    ws.onopen = () => res({ ws, msgs, next: async (pred, ms = 3000) => { const t = Date.now(); for (;;) { const i = msgs.findIndex(pred); if (i >= 0) return msgs.splice(i, 1)[0]; if (Date.now() - t > ms) return null; await new Promise(r => { wake = r; setTimeout(r, 50); }); } } });
    ws.onerror = rej;
  });
}
const connectPkt = (id, port, host) => { const p = Buffer.alloc(3 + host.length); p[0] = 1; p.writeUInt16LE(port, 1); p.write(host, 3); return pkt(T.CONNECT, id, p); };

(async () => {
  const echo = net.createServer(s => s.pipe(s)).listen(0, '127.0.0.1'); await sleep(100);
  const echoPort = echo.address().port;

  // 1) private addresses allowed (test mode)
  const r1 = await startRelay(18081, { ALLOW_PRIVATE: '1' });
  let c = await open(18081);
  const first = await c.next(m => m[0] === T.CONTINUE);
  ok(first && first.readUInt32LE(1) === 0 && first.readUInt32LE(5) > 0, 'server sends initial CONTINUE on stream 0');
  c.ws.send(connectPkt(1, echoPort, '127.0.0.1'));
  const cont = await c.next(m => m[0] === T.CONTINUE && m.readUInt32LE(1) === 1);
  ok(!!cont, 'CONNECT to TCP target accepted (stream CONTINUE received)');
  c.ws.send(pkt(T.DATA, 1, Buffer.from('hello java server')));
  const echoed = await c.next(m => m[0] === T.DATA && m.readUInt32LE(1) === 1);
  ok(echoed && echoed.subarray(5).toString() === 'hello java server', 'DATA is relayed to TCP and echoed back');
  const big = Buffer.alloc(100000, 7);   // exercises 64-bit WebSocket length path
  c.ws.send(pkt(T.DATA, 1, big)); let got = 0, bad = false;
  while (got < big.length) { const m = await c.next(m => m[0] === T.DATA && m.readUInt32LE(1) === 1, 4000); if (!m) break; got += m.length - 5; if (m.subarray(5).some(b => b !== 7)) bad = true; }
  ok(got === big.length && !bad, '100 KB payload round-trips intact (' + got + ' bytes)');
  c.ws.send(pkt(T.CLOSE, 1, Buffer.from([2]))); await sleep(200);
  c.ws.send(connectPkt(2, 1, '127.0.0.1'));   // port 1: nothing listening
  const refused = await c.next(m => m[0] === T.CLOSE && m.readUInt32LE(1) === 2);
  ok(refused && refused[5] === 0x44, 'closed port reports CLOSE reason 0x44 (refused)');
  c.ws.send(connectPkt(3, 22, '127.0.0.1'));
  const blockedPort = await c.next(m => m[0] === T.CLOSE && m.readUInt32LE(1) === 3);
  ok(blockedPort && blockedPort[5] === 0x47, 'blocked port (22) reports CLOSE reason 0x47');
  c.ws.close(); r1.kill();

  // 2) default policy: localhost / LAN must be blocked
  const r2 = await startRelay(18082, {});
  c = await open(18082); await c.next(m => m[0] === T.CONTINUE);
  c.ws.send(connectPkt(1, echoPort, '127.0.0.1'));
  const b1 = await c.next(m => m[0] === T.CLOSE && m.readUInt32LE(1) === 1);
  ok(b1 && b1[5] === 0x47, 'default policy blocks 127.0.0.1');
  c.ws.send(connectPkt(2, 25565, '192.168.1.10'));
  const b2 = await c.next(m => m[0] === T.CLOSE && m.readUInt32LE(1) === 2);
  ok(b2 && b2[5] === 0x47, 'default policy blocks 192.168.x.x');
  c.ws.send(connectPkt(3, 25565, 'localhost'));
  const b3 = await c.next(m => m[0] === T.CLOSE && m.readUInt32LE(1) === 3);
  ok(b3 && b3[5] === 0x47, 'default policy blocks hostnames that resolve to localhost');
  c.ws.close(); r2.kill(); echo.close();
  console.log(fails ? fails + ' FAILED' : 'ALL TESTS PASSED'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('test error', e); process.exit(1); });

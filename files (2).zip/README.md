# Eagler → Java relay (Wisp server)

Lets Eaglercraft clients that include **Wispcraft** (Depth Client, Depth Client 2, etc.) join normal Minecraft **Java** servers.
It is a standard Wisp server: the browser opens a WebSocket to this program, and this program opens the TCP connection to the Java server.
Minecraft protocol handling and the Microsoft login stay inside Wispcraft.

## Run it
Needs Node.js 18+ (no `npm install`, no dependencies).

    node wisp-relay.js

It listens on port 8080. Check it by opening `http://YOUR-HOST:8080/` — you should see "Eagler -> Java relay (Wisp) is running."

Self-test (starts its own copies, needs no internet):

    node test.js

## Use it from the client
1. Multiplayer → click the **WispSet** (Depth Client 2) or **Wispcraft Settings** (Depth Client) entry.
2. Settings tab → set the **Proxy URL** to your relay, e.g. `ws://192.168.1.20:8080/` or `wss://relay.example.com/`.
3. Add a server whose address starts with `java://`, e.g. `java://play.example.com` (add `:port` if it isn't 25565).
4. Sign in with Microsoft in the same window for online-mode servers.

## No PC? Free hosting from a Chromebook (Render)
1. Make a free account at github.com, create a **new public repository**, and upload every file from this folder (Add file → Upload files).
2. Make a free account at render.com → **New → Blueprint** (or **New → Web Service**) → connect that GitHub repo.
   Blueprint reads `render.yaml` for you. For a manual Web Service use: Runtime **Node**, Build command *(leave empty)*, Start command `node wisp-relay.js`, Instance type **Free**, and add the environment variable `TRUST_PROXY=1`.
3. When it finishes deploying, Render shows an address like `https://eagler-java-relay.onrender.com`. In the client, set the Proxy URL to `wss://eagler-java-relay.onrender.com/`.
Notes: free Render web services go to sleep after about 15 minutes with no traffic and take roughly a minute to wake, so open the address in a browser tab first and wait. Free-tier terms change, and some hosts forbid proxy-style services, so check Render's current terms before you rely on it.
Other option: many Chromebooks can run Linux (Settings → Advanced → Developers → Linux development environment). If yours allows it, install Node there and run the relay on the Chromebook itself, with a Cloudflare Tunnel for the address.

## Where to host it
This has to run on a computer or server that stays on. A Chromebook is not a good host.
- **Same Wi-Fi only:** run it on a PC, use `ws://<that PC's LAN IP>:8080/`. Works from a file:// copy of the client.
- **From anywhere:** run it on a VPS / home server and put HTTPS in front, because browsers on https pages only allow `wss://`.
  Quickest way is a Cloudflare Tunnel: `cloudflared tunnel --url http://localhost:8080` prints a `https://….trycloudflare.com` address → use `wss://` + that host as the Proxy URL.
  Behind a proxy set `TRUST_PROXY=1` so per-IP limits see real client addresses.

## Safety defaults (important)
A TCP relay can be abused if it is open to the internet. By default this one:
- **blocks localhost and LAN/private addresses** (stops people using it to reach your home network) — checked on the resolved IP, so DNS tricks don't bypass it;
- blocks risky ports (22, 23, 25, 135, 139, 445, 465, 587, 3389);
- allows 16 streams per connection and 6 connections per IP.

Tighten it for a public relay, e.g. `ALLOWED_PORTS=25565-25575 ALLOWED_HOSTS=*.hypixel.net,play.example.com`.
Only set `ALLOW_PRIVATE=1` if you deliberately want to reach servers on your own LAN.

## Settings
`PORT`, `HOST`, `ALLOW_PRIVATE`, `ALLOWED_HOSTS`, `ALLOWED_PORTS`, `BLOCKED_PORTS`, `MAX_STREAMS`, `MAX_CONN_PER_IP`, `TRUST_PROXY`, `ALLOWED_ORIGINS` — see the comment at the top of `wisp-relay.js`.

## Not covered
Wisp is TCP-only here (UDP streams are refused). This is not an Eaglercraft *server* relay (EaglerXServer / Eaglercraft relay for LAN worlds).

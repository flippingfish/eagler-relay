#!/usr/bin/env node
/*
 * Eagler -> Java relay (Wisp server)  -  zero dependencies, Node.js 18+
 *
 * Eaglercraft clients that include Wispcraft (Depth Client, etc.) speak the
 * "Wisp" protocol over a WebSocket. This server accepts that WebSocket and
 * opens plain TCP connections to Minecraft Java servers on the client's behalf.
 * Minecraft protocol handling and Microsoft login stay inside Wispcraft.
 *
 * Config (environment variables):
 *   PORT=8080               listen port
 *   HOST=0.0.0.0            listen address
 *   ALLOW_PRIVATE=0         1 = allow connections to localhost / LAN addresses (off by default, see README)
 *   ALLOWED_HOSTS=          comma list of allowed hostnames or *.suffix patterns (empty = any public host)
 *   BLOCKED_PORTS=22,23,25,135,139,445,465,587,3389   ports that clients may not reach
 *   ALLOWED_PORTS=          comma list / ranges like 25565,25500-25600 (empty = any non-blocked port)
 *   MAX_STREAMS=16          simultaneous TCP streams per WebSocket
 *   MAX_CONN_PER_IP=6       simultaneous WebSockets per client IP
 *   TRUST_PROXY=0           1 = read client IP from X-Forwarded-For (use behind Cloudflare/nginx)
 *   ALLOWED_ORIGINS=        comma list of allowed Origin headers (empty = any; note file:// pages send "null")
 */
'use strict';
const http = require('http'), net = require('net'), dns = require('dns'), crypto = require('crypto');

const cfg = {
  port: +process.env.PORT || 8080,
  host: process.env.HOST || '0.0.0.0',
  allowPrivate: process.env.ALLOW_PRIVATE === '1',
  allowedHosts: (process.env.ALLOWED_HOSTS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean),
  blockedPorts: new Set((process.env.BLOCKED_PORTS || '22,23,25,135,139,445,465,587,3389').split(',').map(Number).filter(Boolean)),
  allowedPorts: (process.env.ALLOWED_PORTS || '').split(',').map(s => s.trim()).filter(Boolean).map(s => s.split('-').map(Number)),
  maxStreams: +process.env.MAX_STREAMS || 16,
  maxConnPerIp: +process.env.MAX_CONN_PER_IP || 6,
  trustProxy: process.env.TRUST_PROXY === '1',
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean),
};
const BUFFER = 128;                 // packets a client may send before waiting for a CONTINUE
const MAX_MSG = 1 << 20;            // max WebSocket message size
const CONNECT_TIMEOUT = 10000;
const T = { CONNECT: 1, DATA: 2, CONTINUE: 3, CLOSE: 4 };
const R = { UNSPEC: 1, VOLUNTARY: 2, NETERR: 3, INVALID: 0x41, UNREACH: 0x42, TIMEOUT: 0x43, REFUSED: 0x44, BLOCKED: 0x47, THROTTLED: 0x48 };

// ---------- address policy ----------
function isPrivate(ip) {
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    if (l === '::' || l === '::1') return true;
    const m = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/); if (m) return isPrivate(m[1]);
    return /^f[cd]/.test(l) || /^fe[89ab]/.test(l);
  }
  const p = ip.split('.').map(Number); if (p.length !== 4 || p.some(n => !(n >= 0 && n <= 255))) return true;
  const [a, b] = p;
  return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 100 && b >= 64 && b <= 127) ||
    (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
    (a === 192 && b === 0 && p[2] === 0) || (a === 198 && (b === 18 || b === 19));
}
function hostAllowed(h) {
  if (!cfg.allowedHosts.length) return true;
  h = h.toLowerCase();
  return cfg.allowedHosts.some(p => p.startsWith('*.') ? (h === p.slice(2) || h.endsWith(p.slice(1))) : h === p);
}
function portAllowed(p) {
  if (!(p > 0 && p < 65536) || cfg.blockedPorts.has(p)) return false;
  if (!cfg.allowedPorts.length) return true;
  return cfg.allowedPorts.some(r => r.length === 1 ? p === r[0] : (p >= r[0] && p <= r[1]));
}
function resolveTarget(host) {
  return new Promise((res, rej) => {
    if (net.isIP(host)) return res([{ address: host }]);
    dns.lookup(host, { all: true }, (e, a) => e ? rej(e) : res(a));
  });
}

// ---------- minimal WebSocket server framing ----------
function wsFrame(op, payload) {
  const n = payload.length; let h;
  if (n < 126) h = Buffer.from([0x80 | op, n]);
  else if (n < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(n, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(n), 2); }
  return Buffer.concat([h, payload]);
}
class WsParser {
  constructor(on) { this.on = on; this.buf = Buffer.alloc(0); this.frags = []; this.fragLen = 0; this.fragOp = 0; }
  push(chunk) {
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    for (;;) {
      const b = this.buf; if (b.length < 2) return true;
      const fin = !!(b[0] & 0x80), op = b[0] & 0x0f, masked = !!(b[1] & 0x80); let len = b[1] & 0x7f, off = 2;
      if (!masked) return false;                       // clients must mask
      if (len === 126) { if (b.length < 4) return true; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return true; const big = b.readBigUInt64BE(2); if (big > BigInt(MAX_MSG)) return false; len = Number(big); off = 10; }
      if (len > MAX_MSG) return false;
      if (b.length < off + 4 + len) return true;
      const mask = b.subarray(off, off + 4), data = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < len; i++) data[i] ^= mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      if (op >= 0x8) { this.on(op, data); continue; }  // control frames (close/ping/pong)
      if (op !== 0) { this.fragOp = op; this.frags = []; this.fragLen = 0; }
      this.frags.push(data); this.fragLen += data.length; if (this.fragLen > MAX_MSG) return false;
      if (fin) { const msg = Buffer.concat(this.frags); this.frags = []; this.fragLen = 0; this.on(this.fragOp, msg); }
    }
  }
}

// ---------- Wisp session ----------
const perIp = new Map();
function pkt(type, id, payload) { const b = Buffer.alloc(5 + payload.length); b[0] = type; b.writeUInt32LE(id, 1); payload.copy(b, 5); return b; }
function closePkt(id, reason) { return pkt(T.CLOSE, id, Buffer.from([reason])); }
function contPkt(id, n) { const p = Buffer.alloc(4); p.writeUInt32LE(n, 0); return pkt(T.CONTINUE, id, p); }

function session(sock, ip) {
  const streams = new Map(); let dead = false;
  const send = (buf) => { if (dead || sock.destroyed) return; const ok = sock.write(wsFrame(0x2, buf)); if (!ok) for (const s of streams.values()) s.tcp && s.tcp.pause(); };
  sock.on('drain', () => { for (const s of streams.values()) s.tcp && s.tcp.resume(); });
  const endStream = (id, reason, notify = true) => {
    const s = streams.get(id); if (!s) return; streams.delete(id);
    s.closed = true; if (s.tcp) s.tcp.destroy(); if (notify) send(closePkt(id, reason));
  };
  const teardown = () => { if (dead) return; dead = true; for (const id of [...streams.keys()]) endStream(id, R.VOLUNTARY, false); sock.destroy(); const c = (perIp.get(ip) || 1) - 1; c ? perIp.set(ip, c) : perIp.delete(ip); };
  sock.on('close', teardown); sock.on('error', teardown);

  async function onConnect(id, payload) {
    if (payload.length < 4 || streams.has(id) || id === 0) return send(closePkt(id, R.INVALID));
    if (payload[0] !== 1) return send(closePkt(id, R.INVALID));              // TCP only
    const port = payload.readUInt16LE(1), host = payload.subarray(3).toString('utf8').trim();
    if (!host || host.length > 253 || streams.size >= cfg.maxStreams) return send(closePkt(id, streams.size >= cfg.maxStreams ? R.THROTTLED : R.INVALID));
    if (!hostAllowed(host) || !portAllowed(port)) return send(closePkt(id, R.BLOCKED));
    const st = { tcp: null, queue: [], closed: false }; streams.set(id, st);
    let addrs; try { addrs = await resolveTarget(host); } catch { return endStream(id, R.UNREACH); }
    if (st.closed) return;
    const usable = addrs.filter(a => cfg.allowPrivate || !isPrivate(a.address));
    if (!usable.length) return endStream(id, R.BLOCKED);
    const tcp = net.connect({ host: usable[0].address, port }); st.tcp = tcp;   // connect to the vetted IP, never re-resolve
    tcp.setNoDelay(true); tcp.setTimeout(CONNECT_TIMEOUT, () => { if (!st.connected) endStream(id, R.TIMEOUT); });
    tcp.once('connect', () => {
      if (st.closed) return tcp.destroy(); st.connected = true; tcp.setTimeout(0);
      send(contPkt(id, BUFFER));
      for (const q of st.queue) tcp.write(q); st.queue = [];
    });
    tcp.on('data', d => send(pkt(T.DATA, id, d)));
    tcp.on('end', () => endStream(id, R.VOLUNTARY));
    tcp.on('error', e => endStream(id, e.code === 'ECONNREFUSED' ? R.REFUSED : (e.code === 'ENOTFOUND' || e.code === 'EHOSTUNREACH' || e.code === 'ENETUNREACH') ? R.UNREACH : e.code === 'ETIMEDOUT' ? R.TIMEOUT : R.NETERR));
    tcp.on('close', () => endStream(id, R.VOLUNTARY));
  }
  function onMessage(m) {
    if (m.length < 5) return; const type = m[0], id = m.readUInt32LE(1), payload = m.subarray(5);
    if (type === T.CONNECT) onConnect(id, payload);
    else if (type === T.DATA) {
      const s = streams.get(id); if (!s) return;
      const d = Buffer.from(payload);
      if (s.connected) { s.tcp.write(d, () => send(contPkt(id, BUFFER))); }
      else if (s.queue.length < BUFFER) s.queue.push(d); else endStream(id, R.THROTTLED);
    } else if (type === T.CLOSE) endStream(id, R.VOLUNTARY, false);
  }
  send(contPkt(0, BUFFER));                           // initial flow-control credit
  return onMessage;
}

// ---------- HTTP / upgrade ----------
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const server = http.createServer((req, res) => { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('Eagler -> Java relay (Wisp) is running.\n'); });
server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  const ip = (cfg.trustProxy && (req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';
  const origin = req.headers.origin || 'null';
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { sock.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return; }
  if (cfg.allowedOrigins.length && !cfg.allowedOrigins.includes(origin)) { sock.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return; }
  const n = perIp.get(ip) || 0; if (n >= cfg.maxConnPerIp) { sock.end('HTTP/1.1 429 Too Many Requests\r\n\r\n'); return; }
  perIp.set(ip, n + 1);
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  const proto = (req.headers['sec-websocket-protocol'] || '').split(',')[0].trim();
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + (proto ? '\r\nSec-WebSocket-Protocol: ' + proto : '') + '\r\n\r\n');
  sock.setNoDelay(true);
  const onMessage = session(sock, ip);
  const parser = new WsParser((op, data) => {
    if (op === 0x2) onMessage(data);
    else if (op === 0x8) { sock.write(wsFrame(0x8, data.subarray(0, 2))); sock.end(); }
    else if (op === 0x9) sock.write(wsFrame(0xA, data));
  });
  sock.on('data', c => { if (!parser.push(c)) sock.destroy(); });
});
server.listen(cfg.port, cfg.host, () => {
  console.log(`Eagler -> Java relay listening on ${cfg.host}:${cfg.port}  (private addresses ${cfg.allowPrivate ? 'ALLOWED' : 'blocked'})`);
});
